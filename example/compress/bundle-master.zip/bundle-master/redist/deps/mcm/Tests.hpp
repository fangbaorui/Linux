#ifndef TESTS_HPP_
#define TESTS_HPP_

void runAllTests();

#endif

#ifndef MINIZ_HEADER_FILE_ONLY
#   define MINIZ_HEADER_FILE_ONLY
#   include "miniz.c"
#   undef  MINIZ_HEADER_FILE_ONLY
#endif

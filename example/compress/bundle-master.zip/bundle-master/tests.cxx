#define BUNDLE_BUILD_TESTS
#include "bundle.h"

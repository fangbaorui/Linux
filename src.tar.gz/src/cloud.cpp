#include "cloud.hpp"


int main()
{
    cloud_sys::Server srv;
    srv.Start();
    return 0;
}

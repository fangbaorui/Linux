#include"cloud.hpp"
int main()
{
	cloud_sys::Client client("192.168.154.128", 9000);
	client.Start();
	return 0;
}